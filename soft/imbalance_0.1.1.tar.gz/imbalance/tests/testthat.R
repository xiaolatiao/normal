library(testthat)
library(imbalance)

test_check("imbalance")
