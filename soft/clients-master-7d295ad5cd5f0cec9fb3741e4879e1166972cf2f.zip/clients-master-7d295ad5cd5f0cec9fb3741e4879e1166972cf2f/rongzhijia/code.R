
options(scipen = 9999)

require(dplyr)
require(RPostgreSQL)

### on aug 3, 2017, pull 6mm numbers after deduping, for jaimin to check rongzhijia exisiting customers

require(RPostgreSQL)

con = DBI::dbConnect(dbDriver("PostgreSQL"), 
                     host = '192.168.25.15', 
                     user = 'postgres',
                     password = 'root2017!',
                     dbname = 'score_extraction')

dbListTables(con)

tbl(con, 'extraction_hist')


readRDS('~/data/models/honeypot_model/honeypot_5m_14d.1.0_score_2017-08-02.rds') %>%
  anti_join( tbl(con, 'camp_hist') %>% filter(extraction_id %in% c(1, 2, 4, 5)) %>% select(phone) %>% collect) %>%
  #summarise(n(), max(score), min(score))
  arrange(desc(score)) %>%
  head(6e6) -> extraction

extraction %>% dim
extraction %>% head
extraction %>% select(phone) %>% write_csv('/home/ruser/data/models/honeypot_model/rongzhijia/rzj_check_2017-08-03.csv')




## aug 4, 2017

con = DBI::dbConnect(dbDriver("PostgreSQL"), 
                     host = '192.168.25.15', 
                     user = 'postgres',
                     password = 'root2017!',
                     dbname = 'score_extraction')
dbListTables(con)

read_csv('~/data/models/honeypot_model/rongzhijia/rzj_not_register_phone_0804_a.csv', col_names = F) %>%
  rbind(
    read_csv('~/data/models/honeypot_model/rongzhijia/rzj_not_register_phone_0804_b.csv', col_names = F)
  ) %>%
  mutate(phone = as.character(X1)) %>%
  select(phone) %>%
  mutate(phone_segment = substr(phone, 1, 7)) %>%
  anti_join(
    tbl(con, 'phone_carrier_city') %>% filter(operator == '中国电信') %>% select(phone_segment) %>% collect
  ) %>%
  select(phone) -> tt

1:2 %>%
  walk(function(x) {
    tt %>% filter(row_number() %% 2 == x-1) %>% 
      write_csv(paste0('~/data/models/honeypot_model/rongzhijia/rzj_92w_', 
                       Sys.Date() %>% format, '_', x, '.csv'))
  })


## aug 9, 2017

con = DBI::dbConnect(dbDriver("PostgreSQL"), 
                     host = '192.168.25.15', 
                     user = 'postgres',
                     password = 'root2017!',
                     dbname = 'score_extraction')
dbListTables(con)

read_csv('~/data/clients/rongzhijia/not_rzj_register_phone_0804.csv', col_names = F) %>% 
  mutate(phone = as.character(X1)) %>%
  select(phone) %>%
  mutate(phone_segment = substr(phone, 1, 7)) %>%
  anti_join(
    tbl(con, 'phone_carrier_city') %>% filter(operator == '中国电信') %>% select(phone_segment) %>% collect
  ) %>%
  select(PHONE = phone) -> dd

dd %>% anti_join(
  rbind(
    read_csv('~/data/miaobaitiao_2017-08-09.csv'),
    read_csv('~/data/weimeng_2017-08-09.csv')
  ) %>% mutate(PHONE = as.character(PHONE)) %>%
    rbind(
      read_csv('~/data/test_week_0807.csv') %>% 
        mutate(PHONE = as.character(phone)) %>% select(PHONE) 
    ) %>%
    rbind(
      rbind(
        read_csv('~/data/clients/rongzhijia/cc_tag_1_2017-08-07.csv'),
        read_csv('~/data/clients/rongzhijia/cc_tag_2_2017-08-07.csv'),
        read_csv('~/data/clients/rongzhijia/cc_tag_3_2017-08-07.csv'),
        read_csv('~/data/clients/rongzhijia/cc_tag_4_2017-08-07.csv'),
        read_csv('~/data/clients/rongzhijia/cc_tag_5_2017-08-07.csv'),
        read_csv('~/data/clients/rongzhijia/cc_tag_6_2017-08-07.csv'),
        read_csv('~/data/clients/rongzhijia/cc_tag_7_2017-08-07.csv')
      ) %>% mutate(PHONE = as.character(phone)) %>% select(PHONE) )
  ) -> dd

1:6 %>%
  purrr::walk(function(x) {
    dd %>% filter(row_number() %% 6 == x-1) %>% 
      write_csv(paste0('~/data/clients/rongzhijia/rzj_295w_', 
                       Sys.Date() %>% format, '_', x, '.csv'))
  })



con = DBI::dbConnect(odbc::odbc(), "oracle-camp", uid = 'dev', pwd = 'Oracl1')
str(con)

tbl(con, 'ALL_ALL_TABLES') %>% filter(OWNER == 'DEV')


task = tbl(con, 'MST_TASK') %>% filter(DELETEFLG == '0', PLANNEDQUANTITY > 9999,
                                       DELIVERYTIME >= TO_DATE('2017-08-06', 'yyyy-mm-dd'),
                                       DELIVERYTIME <= TO_DATE('2017-08-08', 'yyyy-mm-dd')) %>%
  select(TASKID = ID, VENDORID, DELIVERYTIME, PLANNEDQUANTITY )  %>% collect

tbl(con, 'DATA_SMS') %>% filter(TASKID %in% task[['TASKID']]) %>% View
  group_by(TASKID) %>%
  summarise(n(), n_distinct(PHONE)) %>% 
  collect %>%
  inner_join( task ) %>% View
  

  
## on Aug 10, insert into data_sms for 2 jobs on aug 11
rbind(
  read_csv('~/data/clients/rongzhijia/rzj_295w_2017-08-09_4.csv'),
  read_csv('~/data/clients/rongzhijia/rzj_295w_2017-08-09_5.csv') ) %>%
  mutate(PHONE = as.character(PHONE)) %>% select(PHONE) %>%
  select(PHONE) %>%
  insert_data_sms('b04da17c7db04c64b35180439e6275fa', '12')  


read_csv('~/data/clients/rongzhijia/cc_tag_4_2017-08-07.csv') %>%
  mutate(PHONE = as.character(phone)) %>%
  insert_data_sms('d3993d86a7fb4da8a03a2d52aa351b46', '20')


## on aug 16, pull 2mm phones based on model 15 and dedup, pass to jaimin to check rzj client base
## no telecom 

require(RPostgreSQL)
con_pg = DBI::dbConnect(dbDriver("PostgreSQL"), 
                        host = '192.168.25.15', 
                        user = 'postgres',
                        password = 'root2017!',
                        dbname = 'score_extraction')

tbl(con_pg, 'phone_carrier_city') %>% select(phone_segment, operator) %>% collect -> ref


tbl(con_ora_prod, 'PHONE_SCORE') %>% filter(MODELID == '15') %>%
  anti_join( ## dedup numbers sent in pre and post 3 days
    tbl(con_ora_prod, 'DATA_SMS') %>% filter(TASKID %in% get_taskid('2017-08-13', '2017-08-19')[['TASKID']]) %>% select(PHONE)
  ) %>%
  anti_join( tbl(con_ora_prod, 'PLAN_PHONE') %>% select(PHONE) ) %>% ## only contains 2 files for biyi on aug 15 and 16
  select(PHONE, SCORE) %>%
  arrange(desc(SCORE)) %>%
  head(2500000) %>%
  collect %>%
  mutate(phone_segment = substr(PHONE, 1, 7)) %>%
  anti_join(
    ref %>% filter(operator == '中国电信') ## unicom only
  ) -> dd 

nrow(dd)

con_pg_rzj = DBI::dbConnect(dbDriver("PostgreSQL"), 
                            host = '192.168.25.15', 
                            user = 'postgres',
                            password = 'root2017!',
                            dbname = 'rzj')
  
dd %>% select(PHONE, SCORE) %>% 
  dbWriteTable(con_pg, 'rzj_to_check', ., row.names = F, overwrite = T)

tbl(con_pg_rzj, 'rzj_to_check') %>% summarise(n())

## insert to plan_phone for easy dedup
## dd %>% select(PHONE) %>% insert_plan_phone('2017-08-16', '15', 'rzj')

dbListTables(con_pg_rzj)

## jaimin identified 600k non-rzj clients
tbl(con_pg_rzj, "rzj_to_check_to_send") %>% summarise(n(), n_distinct(phone))

tbl(con_pg_rzj, "rzj_to_check_to_send") %>% rename(PHONE = phone) %>%
  inner_join(tbl(con_pg_rzj, "rzj_to_check")) %>%
  collect -> dd

dd %>% summarise(n(), n_distinct(PHONE))

dd %>% sample_frac(0.5) -> dd1
dd1 %>% pull(SCORE) %>% summary
dd %>% anti_join(dd1 %>% select(PHONE)) -> dd2
dd2 %>% pull(SCORE) %>% summary
# get_taskid('2017-08-18', '2017-08-18')

dd1 %>% select(PHONE) %>% insert_data_sms('b9e6107c7913412a8791c91f806c76d2', '15')
dd2 %>% select(PHONE) %>% insert_data_sms('1ff49c6c53de4fc7a62519c5ceeda24c', '15')

# dd = tbl(con_ora_prod, 'PLAN_PHONE') %>% filter(CLIENT == 'rzj') %>% select(PHONE) %>% collect
# dd %>% dim
# 
# dd1 = tbl(con_ora_prod, 'DATA_SMS') %>% filter(TASKID == 'b9e6107c7913412a8791c91f806c76d2') %>%
#   select(PHONE) %>% collect
# dd1 %>% dim
# 
# dd2 = dd %>% anti_join(dd1)
# dd2 %>% dim
# 
# dd1 %>% semi_join(dd2)
# 
# insert_data_sms('1ff49c6c53de4fc7a62519c5ceeda24c', '15')


## on aug 18, pull 4.4mm phones based on model 15 and dedup, pass to jaimin to check rzj client base
## no telecom 

require(RPostgreSQL)
con_pg_util = DBI::dbConnect(dbDriver("PostgreSQL"), 
                        host = '192.168.25.15', 
                        user = 'postgres',
                        password = 'root2017!',
                        dbname = 'score_extraction')

tbl(con_pg_util, 'phone_carrier_city') %>% select(phone_segment, operator) %>% collect -> ref


tbl(con_ora_prod, 'PHONE_SCORE') %>% filter(MODELID == '15') %>%
  anti_join( ## dedup numbers sent in pre and post 3 days
    tbl(con_ora_prod, 'DATA_SMS') %>% filter(TASKID %in% get_taskid('2017-08-18', '2017-08-24')[['TASKID']]) %>% select(PHONE)
  ) %>%
  anti_join( tbl(con_ora_prod, 'PLAN_PHONE') %>% 
               filter(INSERTDATE > '2017-08-15') %>% select(PHONE) ) %>% ## only contains 2 files for biyi on aug 15 and 16
  select(PHONE, SCORE) %>%
  arrange(desc(SCORE)) %>%
  head(5e6) %>%
  collect %>%
  mutate(phone_segment = substr(PHONE, 1, 7)) %>%
  anti_join(
    ref %>% filter(operator == '中国电信') ## unicom only
  ) -> dd 

nrow(dd)

con_pg_rzj = DBI::dbConnect(dbDriver("PostgreSQL"), 
                            host = '192.168.25.15', 
                            user = 'postgres',
                            password = 'root2017!',
                            dbname = 'rzj')

dd %>% select(PHONE, SCORE) %>% 
  dbWriteTable(con_pg_rzj, 'rzj_to_check', ., row.names = F, overwrite = T)

tbl(con_pg_rzj, 'rzj_to_check') %>% summarise(n())

tbl(con_pg_rzj, 'rzj_to_check_to_send') %>% summarise(n())

## jaimin identified 1.28mm non-rzj clients, going to be sent in the week of aug 21
## insert them into plan_phone for easy dedup
dd = read_csv('~/data/clients/rongzhijia/rzj_to_check_not_20.csv', 
              col_names = F, col_types = 'c') %>%
  rename(PHONE = X1)

dd %>% select(PHONE) %>% insert_plan_phone('2017-08-20', '15', 'rzj')

