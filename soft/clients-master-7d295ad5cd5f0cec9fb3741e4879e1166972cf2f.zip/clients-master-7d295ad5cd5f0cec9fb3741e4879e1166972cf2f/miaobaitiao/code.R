## this file records data extraction for miaobaitiao

options(scipen = 9999)

require(dplyr)
require(readr)
require(DBI)


## remove phone numbers with less than 6 month phone records and limit age between 18 and 50

tbl(con_risk, 'TBL_RISK_MANAGEMENT') %>% 
  select(APP_CP, APP_CT, APP_IDCN, CPA_RT) %>%
  distinct %>%
  collect -> risk 

risk %>% rename(PHONE = APP_CP, IDCARD = APP_IDCN) %>% 
  filter(CPA_RT >= '2017-03' | CPA_RT == '未知') %>%
  semi_join(
    read_csv('/home/ruser/data/miaobaitiao_blacklist_2017-08-03.csv') %>%
      mutate(PHONE = as.character(PHONE))
  ) %>%
  select(PHONE) %>% distinct -> le_6m 

## age 18 ~ 50
read_csv('/home/ruser/data/miaobaitiao_blacklist_2017-08-03.csv') %>%
  mutate(PHONE = as.character(PHONE), 
         age = case_when(
           nchar(IDCARD) == 18 ~ 2017 - as.integer(substr(IDCARD, 7,10)),
           nchar(IDCARD) == 15 ~ 117 -  as.integer(substr(IDCARD, 7, 8)))) %>%
  filter(age >= 18, age <= 50) 

nrow(le_6m)

read_csv('~/data/miaobaitiao_167w_2017-08-02.csv') %>% 
  filter(grp != 1) %>%
  mutate(PHONE = as.character(phone)) %>%
  anti_join(le_6m) %>%
  semi_join(
    read_csv('/home/ruser/data/miaobaitiao_blacklist_2017-08-03.csv') %>%
      mutate(PHONE = as.character(PHONE), 
             age = case_when(
               nchar(IDCARD) == 18 ~ 2017 - as.integer(substr(IDCARD, 7,10)),
               nchar(IDCARD) == 15 ~ 117 -  as.integer(substr(IDCARD, 7, 8)))) %>%
      filter(age >= 18, age <= 50)
  ) %>%
  select(-PHONE) -> big_file

2:4 %>%
  walk(function(x) {
    big_file %>% filter(grp == x) %>%
      write_csv(paste0('~/data/miaobaitiao_119w_', Sys.Date() %>% format, '_', x, '.csv'))
  }) 


## 2017-08-08

con_ora_prod = DBI::dbConnect(odbc::odbc(), "oracle-camp", uid = 'dev', pwd = 'Oracl1')
str(con_ora_prod)


tbl(con, 'PHONE_SCORE') %>% filter(MODELID == '12') %>% select(PHONE, SCORE) %>%
  anti_join(tbl(con, 'PHONE_POOL') %>% filter(CARRIER == '3')) %>%
  arrange(desc(SCORE)) %>%
  head(2.5e6) %>% collect %>%
  anti_join(
    rbind(
      read_csv('~/data/miaobaitiao_119w_2017-08-04_4.csv'),
      read_csv('~/data/miaobaitiao_119w_2017-08-04_3.csv')
    ) %>% mutate(PHONE = as.character(phone)) %>% select(PHONE)  %>%
      rbind(
        rbind(
          read_csv('~/data/models/honeypot_model/rongzhijia/rzj_92w_2017-08-04_1.csv'),
          read_csv('~/data/models/honeypot_model/rongzhijia/rzj_92w_2017-08-04_2.csv')
        ) %>% mutate(PHONE = as.character(phone)) %>% select(PHONE) 
      ) %>%
      rbind(
        read_csv('~/data/test_week_0807.csv') %>% 
          mutate(PHONE = as.character(phone)) %>% select(PHONE) 
      ) 
  ) -> dd

dd %>% summarise(n(), min(SCORE), mean(SCORE), max(SCORE))

part1 = dd %>% sample_frac(0.5) %>% select(PHONE)
part1 %>% write_csv('~/data/clients/miaobaitiao/miaobaitiao_2017-08-09.csv')

dd %>% anti_join(part1) %>% select(PHONE) %>% write_csv('~/dataclients/others/weimeng_2017-08-09.csv')



## aug 9, 2017, pull 300k for miaobaitiao camp on aug 10

tbl(con, 'MST_TASK') %>% filter(DELETEFLG == 0, VENDORID == 'v2') %>% View

tbl(con, 'DATA_SMS') %>% head %>% View
                                
## get the task id for lead generation
tbl(con_ora_prod, 'MST_TASK') %>% 
  filter(to_char(DELIVERYTIME, 'yyyy-mm-dd') == '2017-08-10', ## to_data() convert to 00:00:00
         DELETEFLG == 0) %>% 
  select(TASKID = ID, DELIVERYTIME, VENDORID) %>% 
  collect -> task


## check tasks in last 3 days
tbl(con_ora_prod, 'MST_TASK') %>% 
  filter(to_char(DELIVERYTIME, 'yyyy-mm-dd') >= '2017-08-07', 
         to_char(DELIVERYTIME, 'yyyy-mm-dd') <= '2017-08-09', ## to_data() convert to 00:00:00
         DELETEFLG == 0) %>% 
  select(TASKID = ID, DELIVERYTIME, VENDORID) %>% 
  collect -> task

tbl(con, 'DATA_SMS') %>% filter(TASKID %in% task[['TASKID']]) %>% 
  group_by(TASKID, MODELID) %>% tally %>%
  collect %>% 
  inner_join(task) %>% View

rbind(
  read_csv('~/data/weimeng_2017-08-09.csv'),
  read_csv('~/data/test_week_0807.csv') %>% select(PHONE = phone) ) %>%
  mutate(PHONE = as.character(PHONE)) %>%
  rbind(
    rbind(
      read_csv('~/data/clients/rongzhijia/cc_tag_3_2017-08-07.csv'),
      read_csv('~/data/clients/rongzhijia/cc_tag_4_2017-08-07.csv'),
      read_csv('~/data/clients/rongzhijia/cc_tag_5_2017-08-07.csv'),
      read_csv('~/data/clients/rongzhijia/cc_tag_6_2017-08-07.csv'),
      read_csv('~/data/clients/rongzhijia/cc_tag_7_2017-08-07.csv')
    ) %>% mutate(PHONE = as.character(phone)) %>% select(PHONE) ) %>%
  rbind(
    rbind(
      read_csv('~/data/clients/rongzhijia/rzj_295w_2017-08-09_2.csv'),
      read_csv('~/data/clients/rongzhijia/rzj_295w_2017-08-09_3.csv'),
      read_csv('~/data/clients/rongzhijia/rzj_295w_2017-08-09_4.csv'),
      read_csv('~/data/clients/rongzhijia/rzj_295w_2017-08-09_5.csv'),
      read_csv('~/data/clients/rongzhijia/rzj_295w_2017-08-09_6.csv') ) %>%
      mutate(PHONE = as.character(PHONE)) %>% select(PHONE) ) -> future_number

## select phones based on modelid 12 and dedup
tbl(con, 'PHONE_SCORE') %>% filter(MODELID == '12') %>%
  anti_join( tbl(con, 'PHONE_POOL') %>% filter(CARRIER == '3') %>% select(PHONE) ) %>% 
  arrange(desc(SCORE)) %>%
  select(PHONE, SCORE) %>%
  anti_join( ## dedup numbers sent in previous 3 days
    tbl(con, 'DATA_SMS') %>% filter(TASKID %in% task[['TASKID']]) %>% select(PHONE)
  ) %>%
  head(1e7) %>%
  collect %>%
  anti_join( future_number ) -> dd ## dedup numbers that will be sent in next a few days

nrow(dd)

dd %>% arrange(desc(SCORE)) %>% head(3e5) %>% pull(SCORE) %>% summary()

dd %>% arrange(desc(SCORE)) %>% head(3e5) %>%
  mutate(TASKID = '07c95947385b4e92944ee8ad7d1f2fc6', DELETEFLG = 0, MODELID = '12', PATRITION = substr(PHONE, 10, 11),
         ID = paste0('manual_id_', Sys.Date() %>% format, '_', 1:3e5)) %>%
  select(MODELID, PHONE, TASKID, PATRITION, DELETEFLG, ID) %>%
  dbWriteTable(con, 'DATA_SMS', ., append = T, row.names = F)



## aug 10, 2017, pull 400k for miaobaitiao camp on aug 11 and another 400k on aug 14

### for aug 11 camp
tbl(con, 'PHONE_SCORE') %>% filter(MODELID == '12') %>%
  anti_join( tbl(con, 'PHONE_POOL') %>% filter(CARRIER == '3') %>% select(PHONE) ) %>% ## ex telecom
  select(PHONE, SCORE) %>%
  anti_join( ## dedup numbers sent in previous 3 days
    tbl(con, 'DATA_SMS') %>% filter(TASKID %in% get_taskid('2017-08-08', '2017-08-14')[['TASKID']]) %>% select(PHONE)
  ) %>%
  anti_join( tbl(con_ora_prod, 'PLAN_PHONE') %>% select(PHONE) ) %>% ## dedup numbers that will be sent in next a few days
  arrange(desc(SCORE)) %>%
  head(450000) %>%
  collect -> dd 

dd %>% dim

dd %>% pull(SCORE) %>% summary

# tbl(con_ora_risk, 'TBL_RISK_MANAGEMENT') %>% 
#   filter(CPA_RT <= '2017-03-01') %>%
#   select(APP_CP, CPA_RT) %>%
#   collect -> risk

## ref is created in another extraction by read in ~/data/models/honeypot_model/query_2017-0[3-7].rds
## to save time, reuse it for this extraction
ref %>% semi_join(dd) %>% group_by(PHONE) %>% filter(n() == 1) -> ref_dedup

ref_dedup %>% nrow
ref_dedup %>% head

dd %>% left_join(ref_dedup) %>%
  mutate(
    age = case_when(
      nchar(IDCARD) == 18 & !is.na(IDCARD) ~ 2017 - as.integer(substr(IDCARD, 7,10)),
      nchar(IDCARD) == 15 & !is.na(IDCARD) ~ 117 -  as.integer(substr(IDCARD, 7, 8)))
  ) %>%
  filter(age >= 18, age <= 50) %>%
  semi_join(risk %>% rename(PHONE = APP_CP)) %>%
  arrange(desc(SCORE)) %>% 
  head(400000) %>%
  select(PHONE) %>%
  insert_data_sms('4017b1eddf814f2694538f66e4846623', '12')


### for aug 14 camp
tbl(con, 'PHONE_SCORE') %>% filter(MODELID == '12') %>%
  anti_join( tbl(con, 'PHONE_POOL') %>% filter(CARRIER == '3') %>% select(PHONE) ) %>% ## ex telecom
  select(PHONE, SCORE) %>%
  anti_join( ## dedup numbers sent in previous 3 days
    tbl(con, 'DATA_SMS') %>% filter(TASKID %in% get_taskid('2017-08-11', '2017-08-17')[['TASKID']]) %>% select(PHONE)
  ) %>%
  anti_join( tbl(con_ora_prod, 'PLAN_PHONE') %>% select(PHONE) ) %>% ## dedup numbers that will be sent in next a few days
  arrange(desc(SCORE)) %>%
  head(450000) %>%
  collect -> dd 

dd %>% dim

dd %>% pull(SCORE) %>% summary

ref %>% semi_join(dd) %>% group_by(PHONE) %>% filter(n() == 1) -> ref_dedup

ref_dedup %>% nrow
ref_dedup %>% head

dd %>% left_join(ref_dedup) %>%
  mutate(
    age = case_when(
      nchar(IDCARD) == 18 & !is.na(IDCARD) ~ 2017 - as.integer(substr(IDCARD, 7,10)),
      nchar(IDCARD) == 15 & !is.na(IDCARD) ~ 117 -  as.integer(substr(IDCARD, 7, 8)))
  ) %>%
  filter(age >= 18, age <= 50) %>%
  semi_join(risk %>% rename(PHONE = APP_CP)) %>%
  arrange(desc(SCORE)) %>% 
  head(400000) %>% #summarise(min(SCORE), mean(SCORE), max(SCORE))
  select(PHONE) %>%
  insert_data_sms('cf9d6f15193546cb9d646cf3f233a15e', '12')
  

  
## aug 15, 2017, pull 400k for miaobaitiao camp on aug 15

tbl(con, 'PHONE_SCORE') %>% filter(MODELID == '12') %>%
  anti_join( tbl(con, 'PHONE_POOL') %>% filter(CARRIER == '3') %>% select(PHONE) ) %>% ## ex telecom
  select(PHONE, SCORE) %>%
  anti_join( ## dedup numbers sent in previous 3 days
    tbl(con, 'DATA_SMS') %>% filter(TASKID %in% get_taskid('2017-08-12', '2017-08-18')[['TASKID']]) %>% select(PHONE)
  ) %>%
  anti_join( tbl(con_ora_prod, 'PLAN_PHONE') %>% filter(CLIENT != 'rzj') %>% select(PHONE) ) %>% ## dedup numbers that will be sent in next a few days
  arrange(desc(SCORE)) %>%
  head(450000) %>%
  collect -> dd 

dd %>% dim

dd %>% pull(SCORE) %>% summary


ref %>% semi_join(dd) %>% group_by(PHONE) %>% filter(n() == 1) -> ref_dedup

ref_dedup %>% nrow
ref_dedup %>% head

dd %>% left_join(ref_dedup) %>%
  mutate(
    age = case_when(
      nchar(IDCARD) == 18 & !is.na(IDCARD) ~ 2017 - as.integer(substr(IDCARD, 7,10)),
      nchar(IDCARD) == 15 & !is.na(IDCARD) ~ 117 -  as.integer(substr(IDCARD, 7, 8)))
  ) %>%
  filter(age >= 18, age <= 50) %>%
  semi_join(risk %>% rename(PHONE = APP_CP)) %>%
  arrange(desc(SCORE)) %>% 
  #head(400000) %>% 
  #summarise(n(), n_distinct(PHONE), min(SCORE), mean(SCORE), max(SCORE))
  select(PHONE) %>%
  insert_data_sms('53833147deff4e768a63708a611cbf9f', '12')

  
  