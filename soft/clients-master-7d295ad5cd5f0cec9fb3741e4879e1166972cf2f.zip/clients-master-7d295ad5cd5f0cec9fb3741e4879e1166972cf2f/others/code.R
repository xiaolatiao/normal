## this file records data extraction for other firms (other than rzj and miaobaitiao for now)


## aug 6, select 1 mm records by honeypot score, excluding numbers for rzj and miaobaitiao
## exclude china telecom

require(RPostgreSQL)

con = DBI::dbConnect(dbDriver("PostgreSQL"), 
                     host = '192.168.25.15', 
                     user = 'postgres',
                     password = 'root2017!',
                     dbname = 'score_extraction')

dbListTables(con)
tbl(con, 'phone_carrier_city') %>% head

readRDS('~/data/models/honeypot_model/honeypot_5m_14d.1.0_score_2017-08-02.rds') %>%
  anti_join(
    read_csv('~/data/miaobaitiao_167w_2017-08-02.csv') %>%
      mutate(phone = as.character(phone))
  ) %>%
  anti_join(
    read_csv('/home/ruser/data/models/honeypot_model/rongzhijia/rzj_not_register_phone_0804_a.csv', col_names = F) %>%
      mutate(phone = as.character(X1)) ) %>%
  anti_join(
    read_csv('/home/ruser/data/models/honeypot_model/rongzhijia/rzj_not_register_phone_0804_b.csv', col_names = F) %>%
      mutate(phone = as.character(X1)) ) %>%
  anti_join(
    read_csv('/home/ruser/data/models/honeypot_model/rongzhijia/not_rzj_register_phone_0804.csv', col_names = F) %>%
      mutate(phone = as.character(X1)) ) %>%
  mutate(phone_segment = substr(phone, 1, 7)) %>%
  anti_join(
    tbl(con, 'phone_carrier_city') %>% filter(operator == '中国电信') %>%
      select(phone_segment) %>% collect
  ) %>%
  arrange(desc(score)) %>%
  head(1e6) -> dd

dd %>% dim
dd %>% head

dd %>% select(phone) %>% mutate(firm = sample(1:10, nrow(dd), replace = T)) %>%
  group_by(firm) %>% mutate(grp = sample(1:2, n(), replace = T)) -> dd

dd %>% write_csv('~/data/test_week_0807.csv')



## on aug 9, 2017, add age and carrier to test_week_0807.csv
rbind(
  readRDS('~/data/models/honeypot_model/query_2017-03.rds'),
  readRDS('~/data/models/honeypot_model/query_2017-04.rds'),
  readRDS('~/data/models/honeypot_model/query_2017-05.rds'),
  readRDS('~/data/models/honeypot_model/query_2017-06.rds'),
  readRDS('~/data/models/honeypot_model/query_2017-07.rds')
) %>% select(PHONE, IDCARD) -> ref

ref %>% distinct -> ref

require(RPostgreSQL)
con = DBI::dbConnect(dbDriver("PostgreSQL"), 
                     host = '192.168.25.15', 
                     user = 'postgres',
                     password = 'root2017!',
                     dbname = 'score_extraction')

dbListTables(con)
tbl(con, 'phone_carrier_city') %>% select(phone_segment, operator) %>% collect -> carrier_ref

ref %>% semi_join(
  read_csv('~/data/test_week_0807.csv') %>% 
    mutate(phone_segment = substr(phone, 1, 7)) %>%
    left_join(carrier_ref) %>%
    select(-phone_segment) %>%
    mutate(PHONE = as.character(phone))
  
) %>% group_by(PHONE) %>% tally(sort = T) 

ref %>% semi_join(read_csv('~/data/test_week_0807.csv') %>% 
                    mutate(PHONE = as.character(phone))) %>%
  group_by(PHONE) %>% filter(n() == 1) -> ref_dedup

ref_dedup %>% nrow
ref_dedup %>% head

read_csv('~/data/test_week_0807.csv') %>% 
  mutate(phone_segment = substr(phone, 1, 7)) %>%
  left_join(carrier_ref) %>%
  select(-phone_segment) %>%
  mutate(PHONE = as.character(phone)) %>%
  left_join(ref_dedup) %>%
  mutate(
    age = case_when(
      nchar(IDCARD) == 18 & !is.na(IDCARD) ~ 2017 - as.integer(substr(IDCARD, 7,10)),
      nchar(IDCARD) == 15 & !is.na(IDCARD) ~ 117 -  as.integer(substr(IDCARD, 7, 8)))
  ) %>%
  select(-PHONE, -IDCARD) %>%
  write_csv('~/data/test_week_0807_age_carrier.csv')

1:10 %>% 
  purrr::walk( function(x) {
    read_csv('~/data/test_week_0807_age_carrier.csv') %>% 
      filter(firm == x) %>%
      write_csv(paste0('~/data/clients/others/test_week_0807_age_carrier_firm_', x, '.csv'))
  } )


## aug 9, 2017

tbl(con, 'MST_TASK') %>% filter(DELETEFLG == 0, VENDORID == 'v2') %>% View

tbl(con, 'DATA_SMS') %>% head %>% View
                                
## get the task id for lead generation
tbl(con_ora_prod, 'MST_TASK') %>% 
  filter(to_char(DELIVERYTIME, 'yyyy-mm-dd') == '2017-08-10', ## to_data() convert to 00:00:00
         DELETEFLG == 0) %>% 
  select(TASKID = ID, DELIVERYTIME, VENDORID) %>% 
  collect -> task


## check tasks in last 3 days
tbl(con_ora_prod, 'MST_TASK') %>% 
  filter(to_char(DELIVERYTIME, 'yyyy-mm-dd') >= '2017-08-07', 
         to_char(DELIVERYTIME, 'yyyy-mm-dd') <= '2017-08-09', ## to_data() convert to 00:00:00
         DELETEFLG == 0) %>% 
  select(TASKID = ID, DELIVERYTIME, VENDORID) %>% 
  collect -> task

tbl(con, 'DATA_SMS') %>% filter(TASKID %in% task[['TASKID']]) %>% 
  group_by(TASKID, MODELID) %>% tally %>%
  collect %>% 
  inner_join(task) %>% View



tbl(con, 'PHONE_SCORE') %>% filter(MODELID == '12') %>% select(PHONE, SCORE) %>%
  anti_join(tbl(con, 'PHONE_POOL') %>% filter(CARRIER == '3')) %>%
  arrange(desc(SCORE)) %>%
  head(2.5e6) %>% collect %>%
  anti_join(
    rbind(
      read_csv('~/data/miaobaitiao_119w_2017-08-04_4.csv'),
      read_csv('~/data/miaobaitiao_119w_2017-08-04_3.csv')
    ) %>% mutate(PHONE = as.character(phone)) %>% select(PHONE)  %>%
      rbind(
        rbind(
          read_csv('~/data/models/honeypot_model/rongzhijia/rzj_92w_2017-08-04_1.csv'),
          read_csv('~/data/models/honeypot_model/rongzhijia/rzj_92w_2017-08-04_2.csv')
        ) %>% mutate(PHONE = as.character(phone)) %>% select(PHONE) 
      ) %>%
      rbind(
        read_csv('~/data/test_week_0807.csv') %>% 
          mutate(PHONE = as.character(phone)) %>% select(PHONE) 
      ) 
  ) -> dd

dd %>% summarise(n(), min(SCORE), mean(SCORE), max(SCORE))

part1 = dd %>% sample_frac(0.5) %>% select(PHONE)
part1 %>% write_csv('~/data/miaobaitiao_2017-08-09.csv')

dd %>% anti_join(part1) %>% select(PHONE) %>% write_csv('~/data/weimeng_2017-08-09.csv')





## aug 10, 2017, pull 40k unicom for biyi, assuming it will send on aug 11.
## but biyi didn't send it on aug 11. and this list in plan_phone got corrupted. so reload it
## into plan_phone on aug 15. biyi actually sent them out on aug 15. so release aug 19 onwards

## tbl(con_ora_prod, 'PLAN_PHONE') %>% select(PHONE) %>% summarise(n(), n_distinct(PHONE))


## select phones based on modelid 12 and dedup
tbl(con, 'PHONE_SCORE') %>% filter(MODELID == '12') %>%
  semi_join( tbl(con, 'PHONE_POOL') %>% filter(CARRIER == '2') %>% select(PHONE) ) %>% ## unicom phone only
  select(PHONE, SCORE) %>%
  anti_join( ## dedup numbers sent in previous 3 days
    tbl(con, 'DATA_SMS') %>% filter(TASKID %in% get_taskid('2017-08-08', '2017-08-14')[['TASKID']]) %>% select(PHONE)
  ) %>%
  anti_join( tbl(con_ora_prod, 'PLAN_PHONE') %>% select(PHONE) ) %>% ## dedup numbers that will be sent in next a few days
  arrange(desc(SCORE)) %>%
  head(40000) %>%
  collect -> dd 

nrow(dd)

dd %>% arrange(desc(SCORE)) %>% pull(SCORE) %>% summary()

dd %>% select(PHONE) %>% write_csv('~/data/clients/others/biyi_unicom_4w_2017-08-10.csv')

dd %>% select(PHONE) %>%
  insert_plan_phone('2017-08-10', '12', 'biyi')

## reload it to plan_phone on aug 15
dbExecute(con_ora_prod, "delete from plan_phone where CLIENT = 'biyi'")

read_csv('~/data/clients/others/biyi_unicom_4w_2017-08-10.csv') %>%
  mutate(PHONE = as.character(PHONE)) %>%
  insert_plan_phone('2017-08-15', '12', 'biyi')




## on aug 15, pull 50k for 51shandian, 50k for xingxingqiandai and 100k for faxindai camps on aug 16
## unicom only


tbl(con_ora_prod, 'PHONE_SCORE') %>% filter(MODELID == '12') %>%
  semi_join( tbl(con_ora_prod, 'PHONE_POOL') %>% filter(CARRIER == '2') %>% select(PHONE) ) %>% ## unicom phone only
  select(PHONE, SCORE) %>%
  anti_join( ## dedup numbers sent in pre and post 3 days
    tbl(con_ora_prod, 'DATA_SMS') %>% filter(TASKID %in% get_taskid('2017-08-13', '2017-08-19')[['TASKID']]) %>% select(PHONE)
  ) %>%
  anti_join( tbl(con_ora_prod, 'PLAN_PHONE') %>% select(PHONE) ) %>% ## dedup numbers that will be sent in next a few days
  arrange(desc(SCORE)) %>%
  head(220000) %>%
  collect %>%
  anti_join( read_csv('~/data/clients/others/biyi_unicom_4w_2017-08-10.csv') %>%
               mutate(PHONE = as.character(PHONE)) ) -> dd 

nrow(dd)

dd %>% arrange(desc(SCORE)) %>% head(200000) -> dd

dd1 = dd %>% sample_frac(0.5)
nrow(dd1)
dd2 = dd %>% anti_join(dd1 %>% select(PHONE)) %>% sample_frac(0.5)
nrow(dd2)
dd3 = dd %>% anti_join(dd1 %>% select(PHONE)) %>% anti_join(dd2 %>% select(PHONE))
nrow(dd3)

dd1 %>% pull(SCORE) %>% summary
dd1 %>% select(PHONE) %>%
  insert_data_sms('aa23fb51079f4f509e8806e22436b0a5', '12')

dd2 %>% pull(SCORE) %>% summary
dd2 %>% select(PHONE) %>%
  insert_data_sms('41eb7d9a8a7a4938a4ecabd0e2a1908c', '12')

dd3 %>% pull(SCORE) %>% summary
dd3 %>% select(PHONE) %>%
  insert_data_sms('0eed6afcf64a4c8aad0eace35247188e', '12')


## aug 16, 2017, pull 20k unicom for biyi, assuming it will send on aug 11.

## select phones based on modelid 15 and dedup
require(RPostgreSQL)
con_pg = DBI::dbConnect(dbDriver("PostgreSQL"), 
                        host = '192.168.25.15', 
                        user = 'postgres',
                        password = 'root2017!',
                        dbname = 'score_extraction')

tbl(con_pg, 'phone_carrier_city') %>% select(phone_segment, operator) %>% collect -> ref


tbl(con_ora_prod, 'PHONE_SCORE') %>% filter(MODELID == '15') %>%
  anti_join( ## dedup numbers sent in pre and post 3 days
    tbl(con_ora_prod, 'DATA_SMS') %>% filter(TASKID %in% get_taskid('2017-08-13', '2017-08-19')[['TASKID']]) %>% select(PHONE)
  ) %>%
  select(PHONE, SCORE) %>%
  arrange(desc(SCORE)) %>%
  head(150000) %>%
  collect %>%
  mutate(phone_segment = substr(PHONE, 1, 7)) %>%
  semi_join(
    ref %>% filter(operator == '中国联通') ## unicom only
  ) %>%
  anti_join( ## dedup recent 4w unicom numbers sent on aug 15
    read_csv('~/data/clients/others/biyi_unicom_4w_2017-08-10.csv') %>%
      mutate(PHONE = as.character(PHONE))
  ) -> dd 

nrow(dd)

dd %>% arrange(desc(SCORE)) %>% pull(SCORE) %>% summary()

dd %>% select(PHONE) %>% write_csv('~/data/clients/others/biyi_unicom_2w_2017-08-16.csv')

## dd %>% select(PHONE) %>% insert_plan_phone('2017-08-16', '15', 'biyi')



## on aug 16, pull 70k + 30k  unicom for faxindai camp on aug 17

tbl(con_ora_prod, 'PHONE_SCORE') %>% filter(MODELID == '15') %>%
  anti_join( ## dedup numbers sent in pre and post 3 days
    tbl(con_ora_prod, 'DATA_SMS') %>% filter(TASKID %in% get_taskid('2017-08-14', '2017-08-20')[['TASKID']]) %>% select(PHONE)
  ) %>%
  anti_join( ## dedup phones in plan_phone
    tbl(con_ora_prod, 'DATA_SMS') %>% select(PHONE) ) %>%
  select(PHONE, SCORE) %>%
  arrange(desc(SCORE)) %>%
  head(1e6) %>%
  collect %>%
  mutate(phone_segment = substr(PHONE, 1, 7)) %>%
  semi_join(
    ref %>% filter(operator == '中国联通') ## unicom only
  ) -> dd 

nrow(dd)

dd %>% arrange(desc(SCORE)) %>% pull(SCORE) %>% summary()

dd %>% sample_frac(0.3) -> dd1

dd %>% anti_join(dd1 %>% select(PHONE)) -> dd2

get_taskid('2017-08-17', '2017-08-17')

dd1 %>% select(PHONE) %>% insert_data_sms('73ecccf93bec4fd584608d62937b5d83', '15')
dd2 %>% select(PHONE) %>% insert_data_sms('8ca093fbabb34afd9334295bbaeff285', '15')



## on aug 17, pull 100k unicom for faxindai camp on aug 18

tbl(con_ora_prod, 'PHONE_SCORE') %>% filter(MODELID == '15') %>%
  anti_join( ## dedup numbers sent in pre and post 3 days
    tbl(con_ora_prod, 'DATA_SMS') %>% filter(TASKID %in% get_taskid('2017-08-15', '2017-08-21')[['TASKID']]) %>% select(PHONE)
  ) %>%
  anti_join( ## dedup phones in plan_phone
    tbl(con_ora_prod, 'PLAN_PHONE') %>% select(PHONE) ) %>%
  select(PHONE, SCORE) %>%
  arrange(desc(SCORE)) %>%
  head(1e6) %>%
  collect %>%
  mutate(phone_segment = substr(PHONE, 1, 7)) %>%
  semi_join(
    tbl(con_pg_util, 'phone_carrier_city') %>%
      filter(operator == '中国联通') %>% ## unicom only
      select(phone_segment) %>%
      collect
    ) -> dd 

nrow(dd)

dd %>% arrange(desc(SCORE)) %>% pull(SCORE) %>% summary()

dd %>% select(PHONE) %>% insert_data_sms('2cfad268e7634d11bf0f921098ee9721', '15')


## on aug 17, pull 350k moblie/unicom for weimeng camp on aug 18

tbl(con_ora_prod, 'PHONE_SCORE') %>% filter(MODELID == '15') %>%
  anti_join( ## dedup numbers sent in pre and post 3 days
    tbl(con_ora_prod, 'DATA_SMS') %>% filter(TASKID %in% get_taskid('2017-08-15', '2017-08-21')[['TASKID']]) %>% select(PHONE)
  ) %>%
  anti_join( ## dedup phones in plan_phone
    tbl(con_ora_prod, 'PLAN_PHONE') %>% select(PHONE) ) %>%
  select(PHONE, SCORE) %>%
  arrange(desc(SCORE)) %>%
  head(1e6) %>%
  collect %>%
  mutate(phone_segment = substr(PHONE, 1, 7)) %>%
  semi_join(
    tbl(con_pg_util, 'phone_carrier_city') %>%
      filter(operator %in% c('中国联通', '中国移动')) %>% ## unicom only
      select(phone_segment) %>%
      collect
  ) -> dd 

nrow(dd)
dd %>% arrange(-SCORE) %>% head(350000) -> dd
nrow(dd)

dd %>% arrange(desc(SCORE)) %>% pull(SCORE) %>% summary()

dd %>% select(PHONE) %>% insert_data_sms('8ec66e61800040478352548b9be98d8e', '15')



## on aug 18, pull 100k unicom for xinyongbaitiao (v7) camp on aug 18

tbl(con_ora_prod, 'PHONE_SCORE') %>% filter(MODELID == '15') %>%
  anti_join( ## dedup numbers sent in pre and post 3 days
    tbl(con_ora_prod, 'DATA_SMS') %>% filter(TASKID %in% get_taskid('2017-08-15', '2017-08-21')[['TASKID']]) %>% select(PHONE)
  ) %>%
  anti_join( ## dedup phones in plan_phone
    tbl(con_ora_prod, 'PLAN_PHONE') %>% select(PHONE) ) %>%
  select(PHONE, SCORE) %>%
  arrange(desc(SCORE)) %>%
  head(3e6) %>%
  collect %>%
  mutate(phone_segment = substr(PHONE, 1, 7)) %>%
  semi_join(
    tbl(con_pg_util, 'phone_carrier_city') %>%
      filter(operator %in% c('中国联通')) %>% ## unicom only
      select(phone_segment) %>%
      collect
  ) -> dd 

nrow(dd)
dd %>% arrange(-SCORE) %>% head(100000) -> ddd
nrow(ddd)

ddd %>% arrange(desc(SCORE)) %>% pull(SCORE) %>% summary()

ddd %>% select(PHONE) %>% insert_data_sms('d91e0f8a6f0246b5a11cc8c208f9d4ad', '15')

## on aug 18, pull another 500k for xinyongbaitiao (v7) camp on aug 18

tbl(con_ora_prod, 'PHONE_SCORE') %>% filter(MODELID == '15') %>%
  anti_join( ## dedup numbers sent in pre and post 3 days
    tbl(con_ora_prod, 'DATA_SMS') %>% filter(TASKID %in% get_taskid('2017-08-15', '2017-08-21')[['TASKID']]) %>% select(PHONE)
  ) %>%
  anti_join( ## dedup phones in plan_phone
    tbl(con_ora_prod, 'PLAN_PHONE') %>% select(PHONE) ) %>%
  select(PHONE, SCORE) %>%
  arrange(desc(SCORE)) %>%
  head(5e5) %>%
  collect -> dd 

nrow(dd)
#dd %>% arrange(-SCORE) %>% head(100000) -> ddd
#nrow(dd)

dd %>% pull(SCORE) %>% summary()

dd %>% select(PHONE) %>% insert_data_sms('60d206883d5b42cbad42fef26fb2b40a', '15')



## on aug 20, pull 250k for weimeng (v8) camp on aug 21

pull_phone_for_task('15', '5386a434a40941a5892dbde82fd05bf3', 
                    '2017-08-18', '2017-08-24', 
                    '2017-08-16', 
                    300000) %>%
  mutate(phone_segment = substr(PHONE, 1, 7)) %>%
  semi_join(
    tbl(con_pg_util, 'phone_carrier_city') %>%
      filter(operator %in% c('中国联通', '中国移动')) %>% ## unicom only
      select(phone_segment) %>%
      collect
  ) -> dd 

nrow(dd)

dd %>% arrange(-SCORE) %>% head(250000) -> dd
nrow(dd)
dd %>% pull(SCORE) %>% summary()

dd %>% select(PHONE) %>% insert_data_sms('5386a434a40941a5892dbde82fd05bf3', '15')


## on aug 20, pull 700k for xinyongbaitiao (v7) camp on aug 21

pull_phone_for_task('15', 'd644d4da32854e5f92afc0e3a371b97b', 
                    '2017-08-18', '2017-08-24', 
                    '2017-08-16', 
                    700000) -> dd 

nrow(dd)

dd %>% pull(SCORE) %>% summary()

dd %>% select(PHONE) %>% insert_data_sms('d644d4da32854e5f92afc0e3a371b97b', '15')

