print.FMmodel <-
function(x, ...){

  summary(x)

}
