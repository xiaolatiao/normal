
# Sys.setenv(ORACLE_HOME = '/usr/lib/oracle/12.2/client64/',
#            LD_LIBRARY_PATH = '/usr/lib/oracle/12.2/client64/lib/',
#            TWO_TASK = '//172.16.1.222:1512/orcl')

require(dplyr)


## connection to postgres db
require(RPostgreSQL)

con = DBI::dbConnect(dbDriver("PostgreSQL"), 
                      host = '192.168.25.15', 
                      user = 'postgres',
                      password = 'root2017!',
                      dbname = 'tag')
                      

tbl(con, 'consumer_tag479') %>% select(tag_consumer)

## connect to another postgresql for cc label data

con_pg_label = DBI::dbConnect(dbDriver("PostgreSQL"), 
                     host = '10.100.3.4', 
                     user = 'reader',
                     password = 'reader20170802',
                     dbname = 'consumer_tag')

str(con_pg_label)
dbListTables(con_pg_label)
tbl(con_pg_label, 'consumer_tag_all') %>% head(3) %>% View
tbl(con_pg_label, 'consumer_tag_all') %>% summarise(n())

tbl(con_pg_label, 'consumer_tag_all') %>%
  group_by(substr(to_char(update_time, 'yyyy-mm-dd'), 1, 10)) %>%
  tally %>% View


## how to deal with json field

tbl(con, 'consumer_tag_all') %>% select(tag_consumer)

dbGetQuery(con, sql("select tag_consumer #> '{res_data, cc_cnt}' from consumer_tag_all limit 10"))

tbl(con, sql("select tag_consumer::jsonb->'cc_cnt' from consumer_tag_all limit 10"))



## connection to multiple oracle dbs

## http://www.uptimemadeeasy.com/linux/install-oracle-odbc-driver-on-centos/

require(odbc)

odbc::odbcListDrivers()



library(DBI)

con_ora_prod = DBI::dbConnect(odbc::odbc(), "oracle-camp", uid = 'dev', pwd = 'Oracl1')
str(con)

dbListTables(con)
tbl(con, 'ALL_ALL_TABLES') %>% filter(OWNER == 'DEV')

tbl(con_ora_prod, 'MST_VENDOR') %>% head

tbl(con, 'MST_TASK') %>% filter(VENDORID == 'v2', DELETEFLG == '0') %>% arrange(TASKNAME) %>% View

tbl(con, 'MST_TASK') %>% filter(VENDORID == 'v2', DELETEFLG == '0') %>% summarise(sum(PLANNEDQUANTITY))

tbl(con, 'MST_TASK') %>% filter(DELETEFLG == '0', 
                                DELIVERYTIME >= TO_DATE('2017-08-06', 'yyyy-mm-dd'),
                                DELIVERYTIME <= TO_DATE('2017-08-08', 'yyyy-mm-dd')) %>% View

tbl(con, 'MST_TASK') %>% group_by(substr(TASKNAME, 1, 3)) %>% tally %>% View
tbl(con, 'MST_TASK') %>% filter(substr(TASKNAME, 1, 3) == 'rzj') %>% arrange(desc(TASKNAME))
tbl(con, 'MST_TASK') %>% filter(ID == 'a86b72fe58854d44ba24cc72e46acfce')

tbl(con, 'DATA_SMS') %>% select(TASKID)

tbl(con, 'DATA_SMS') %>% filter(TASKID == 'edb1ebbd7f8743d4baf5f07d5f741d57') %>% summarise(n_distinct(MOBILE))
  

tbl(con, 'PHONE_POOL') %>% head
tbl(con, 'PHONE_POOL') %>% summarise(n(), n_distinct(CARRIER))
tbl(con, 'PHONE_POOL') %>% group_by(CARRIER) %>% tally


tbl(con, 'PHONE_SCORE') %>% head(22) %>% View
tbl(con, 'PHONE_SCORE') %>% summarise(n_distinct(PHONE))
tbl(con, 'PHONE_SCORE') %>% group_by(MODELID) %>% tally

tbl(con, 'MST_MODEL') %>% select(ID) %>% distinct %>% View

dbExecute(con, "update MST_MODEL set DESCRIPTION = 'honeypot_5m_14d.1.0', 
          SCORETIME = TO_DATE('2017-08-02', 'yyyy-mm-dd'), 
          BASELINETIME = TO_DATE('2017-07-31', 'yyyy-mm-dd')
          where ID = '12'")

dbExecute(con, "INSERT INTO MST_MODEL 
          (ID, MODELNAME, VERSION, DESCRIPTION) 
          VALUES 
          ('20', 'cc_label', '1.0', 'cc_honeypot_mars_v_1.0')")

dbExecute(con, "UPDATE MST_MODEL set MODELNAME = 'cc_label', 
          SCORETIME = TO_DATE('2017-08-04', 'yyyy-mm-dd'), 
          BASELINETIME = TO_DATE('2017-05-31', 'yyyy-mm-dd')
          where ID = '20'")

dbExecute(con, "UPDATE MST_MODEL set MODELNAME = 'biaoqian' where ID = '20'")


## T_USEGRID_TAKS, JD_APP_FORM / OK now


# con <- dbConnect(odbc::odbc(),
#                  driver = "OracleODBC-12.2",
#                  database = "172.16.1.222:1512/orcl",
#                  uid = "analyzewh_all",
#                  pwd = 'analyzewh_all!2017',
#                  host = "172.16.1.222",
#                  port = 1521)


## oracle-hp defined in /etc/odbc.ini
con_ora_hp = DBI::dbConnect(odbc::odbc(), "oracle-hp", 
                     uid = "analyzewh_all", pwd = 'analyzewh_all!2017')

## check NLS_LANG of oracle 
DBI::dbGetQuery(con, "select * from v$nls_parameters where parameter in ( 'NLS_LANGUAGE','NLS_TERRITORY','NLS_CHARACTERSET')")

##Sys.setenv(NLS_LANG="AMERICAN_AMERICA.AL32UTF8")
## need to figure out the best way to set up the environment variable NLS_LANG
## one option is to set it up in shell, but this only works for R
## another option is to do it in /lib64/R/etc/Renviron.sit (not tried yet, may work for R only too)
## third option is to do it in /etc/rstudio/rserver.conf, see 
## https://support.rstudio.com/hc/en-us/articles/200552316-Configuring-the-Server

tbl(con, 'T_USERGRID_TASK') %>% head
tbl(con, 'JD_APP_FORM') %>% head %>% View
tbl(con_ora_hp, 'JD_APP_FORM') %>% summarise(min(UPDATE_TIME), max(UPDATE_TIME), n_distinct(PHONE), n_distinct(ORG_NAME))
## 2015-4-7 to 2017-7-27, 14mm phone numbers
## https://www.epochconverter.com/ convert number to date


tbl(con, 'T_USERGRID_TASK') %>% glimpse
tbl(con, 'T_USERGRID_TASK') %>% summarise(n(), min(UPDT_DAY), max(UPDT_DAY), n_distinct(PHONE))


tbl(con, 'JD_APP_FORM') %>% summarise(n(), max(UPDATE_TIME)) ## 2017-7-19, checked on 08-04

tbl(con, 'JD_APP_FORM') %>% filter(UPDATE_TIME >= 1483228800000) %>%
  group_by(PHONE) %>% summarise(n = n_distinct(PHONE)) %>% arrange(desc(n))

tbl(con, 'JD_APP_FORM') %>% filter(UPDATE_TIME >= 1493596800000, UPDATE_TIME < 1498867200000) %>% ## 2017-05-01 ~ 2017-06-30
  select(PHONE) %>% 
  semi_join(
    tbl(con, 'T_USERGRID_TASK') %>% filter(UPDT_DAY >= '2017-07-01', UPDT_DAY <= '2017-07-31') %>%
      filter(!AUTH_ORG %in% c('jdzhengxin','jingdong')) %>%
      select(PHONE) ) %>% summarise(n_distinct(PHONE))

tbl(con, 'T_USERGRID_TASK') %>% filter(UPDT_DAY >= '2017-07-01', UPDT_DAY <= '2017-07-31') %>%
  filter(!AUTH_ORG %in% c('jdzhengxin','jingdong')) %>%
  select(PHONE, AUTH_ORG) %>%
  semi_join(
    tbl(con, 'JD_APP_FORM') %>% filter(UPDATE_TIME >= 1493596800000, UPDATE_TIME < 1498867200000) %>% ## 2017-05-01 ~ 2017-06-30
      select(PHONE) ) %>%
  summarise(n_distinct(PHONE))
  group_by(AUTH_ORG) %>% tally(sort = T) %>% View
  

tbl(con, 'T_USERGRID_TASK') %>% filter(UPDT_DAY == '2017-07-27') %>%
  filter(AUTH_ORG == 'jingdong')


## another oracle for TBL_RISK_MANAGEMENT 

library(DBI)

# con <- dbConnect(odbc::odbc(),
#                  driver = "OracleODBC-12.2",
#                  database = "172.16.11.2:1521/wxorcl",
#                  uid = 'analyzedatads',
#                  pwd = 'analyzedatads2016',
#                  host = "172.16.11.2",
#                  port = 1521)

## oracle-hp defined in /etc/odbc.ini

con_ora_risk = DBI::dbConnect(odbc::odbc(), "oracle-risk", 
                     uid = "analyzedatads", pwd = 'analyzedatads2016')


tbl(con_risk, 'TBL_RISK_MANAGEMENT') %>% glimpse
tbl(con_risk, 'TBL_RISK_MANAGEMENT') %>% summarise(n(), max(UPDATE_TIME)) ## 17.4 mm / 2017-08-04, last check 2017-08-04

tbl(con_risk, 'TBL_RISK_MANAGEMENT') %>%
  filter(APP_CT >= '2017-08-04') %>% select(CPA_RT) %>% group_by(substr(CPA_RT, 1, 7)) %>% tally


## mysql

## mysql_src = src_mysql('cc_labels', host = '192.168.25.15', password = 'root2017!')


## write phone_carrier_city table into postgres

require(RPostgreSQL)

con_pg_util = DBI::dbConnect(dbDriver("PostgreSQL"), 
                     host = '192.168.25.15', 
                     user = 'postgres',
                     password = 'root2017!',
                     dbname = 'score_extraction')


tbl(con, 'phone_carrier_city') %>% head
tbl(con, 'phone_carrier_city') %>% summarise(n())


require(jsonlite)

read_json('~/data/phone_segment_map.json', simplifyVector = T) %>% 
  map_df(as_data_frame) %>%
  dbWriteTable(con, 'phone_carrier_city', ., row.names = F)



con_pg_dev = DBI::dbConnect(dbDriver("PostgreSQL"), 
                            host = '10.81.5.1', 
                            port = 25432,
                            user = 'test',
                            password = 'test20170802',
                            dbname = 'datadriver')

dbListTables(con_pg_dev)

tbl(con_pg_dev, 'phone_sms_state') %>% head
