options(scipen = 999)
require(readr)
require(dplyr)

## connect to postgres
require(RPostgreSQL)
require(DBI)

con = DBI::dbConnect(dbDriver("PostgreSQL"), 
                     host = '192.168.25.15', 
                     user = 'postgres',
                     password = 'root2017!',
                     dbname = 'score_extraction')

dbListTables(con)

tbl(con, 'score_hist')

data_frame(score_model = 'honeypot_5m_14d.1.0', score_date = '2017-08-02', score_as_of = '2017-07-31',
           score_id = 3L) %>%
  dbWriteTable(con, 'score_hist', value = ., row.names = F, append = T)


tbl(con, 'extraction_hist') 

data_frame(extraction_id = 5L, extraction_date = '2017-07-25', score_id = 1L, client = 'miaobaitiao',
           extraction_criteria = 'score >= 0.25 and < 0.5', extraction_details = 'rongzhijia existing customers') %>%
  dbWriteTable(con, 'extraction_hist', value = ., row.names = F, append = T)



tbl(con, 'extraction_hist') %>% View
tbl(con, 'extraction_hist') %>% filter(client == 'rongzhijia')
tbl(con, 'camp_hist') %>% summarise(n())
tbl(con, 'camp_hist') %>% group_by(extraction_id) %>% tally
# tbl(con, 'camp_hist') %>% filter(extraction_id %in% c(2, 5)) %>% summarise(n(), n_distinct(phone))


## rongzhijia 
read_csv('~/data/models/honeypot_model/rzj_not_register_phone_0727_dianxin.csv', col_names = F) %>%
  mutate(phone = as.character(X1)) %>% select(phone) %>%
  rbind(
    read_csv('~/data/models/honeypot_model/rzj_not_register_phone_0727_liantong.csv', col_names = F) %>%
      mutate(phone = as.character(X1)) %>% select(phone)
  ) %>%
  rbind(
    read_csv('~/data/models/honeypot_model/rzj_not_register_phone_0727_yidong.csv', col_names = F) %>%
      mutate(phone = as.character(X1)) %>% select(phone)
  ) %>%
  rbind(
    read_csv('~/data/models/honeypot_model/rzj_not_register_phone_0726_a.csv', col_names = F) %>%
      mutate(phone = as.character(X1)) %>% select(phone)
  ) %>% 
  inner_join(
    read_csv('~/data/models/honeypot_model/data_extraction_2017-07-25.csv') %>%
      mutate(phone = as.character(PHONE)) %>%
      select(phone, score)
  ) %>%
  mutate(extraction_id = 4) %>%
  dbWriteTable(con, 'camp_hist', value = ., row.names = F, append = T)
  

## miaobaitiao
read_csv('~/data/models/honeypot_model/miaobaitiao_2017-07-26_mobile.csv') %>%
  mutate(phone = as.character(phone)) %>% select(phone) %>%
  rbind(
    read_csv('~/data/models/honeypot_model/miaobaitiao_2017-07-26_telecom.csv') %>%
      mutate(phone = as.character(phone)) %>% select(phone) ) %>%
  rbind(
    read_csv('~/data/models/honeypot_model/miaobaitiao_2017-07-26_unicom.csv') %>%
      mutate(phone = as.character(phone)) %>% select(phone) ) %>% 
  rbind(
    read_csv('~/data/models/honeypot_model/rzj_register_phone_0726_a.csv', col_names = F) %>%
    mutate(phone = as.character(X1)) %>% select(phone) ) %>%
  rbind(
    read_csv('~/data/models/honeypot_model/rzj_register_phone_0727_dianxin.csv', col_names = F) %>%
      mutate(phone = as.character(X1)) %>% select(phone) ) %>%
  rbind(
    read_csv('~/data/models/honeypot_model/rzj_register_phone_0727_liantong.csv', col_names = F) %>%
      mutate(phone = as.character(X1)) %>% select(phone) ) %>%
  rbind(
    read_csv('~/data/models/honeypot_model/rzj_register_phone_0727_yidong.csv', col_names = F) %>%
      mutate(phone = as.character(X1)) %>% select(phone) ) %>% 
  inner_join(
    read_csv('~/data/models/honeypot_model/data_extraction_2017-07-25.csv') %>%
      mutate(phone = as.character(PHONE)) %>%
      select(phone, score)
  ) %>%
  mutate(extraction_id = 5) %>%
  dbWriteTable(con, 'camp_hist', value = ., row.names = F, append = T)

  