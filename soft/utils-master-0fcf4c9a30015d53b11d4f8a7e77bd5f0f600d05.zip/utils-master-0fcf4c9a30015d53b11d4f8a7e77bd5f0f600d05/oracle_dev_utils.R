##
## scripts to interact with oracle dev database
##


# phone_to_id = function(x) {
#   require(stringr)
#   
#   left = stringi::stri_reverse(substr(x, 1, 7)) %>% as.integer
#   right = stringi::stri_reverse(substr(x, 8, 11)) %>% as.integer
#     
#   pmax(pmin(right, left, 100), 1) %>%
#   purrr::map_int(function(x) {sample.int(x, 1)}) -(right ==0) -> random
#     
#   paste0(str_pad(sprintf('%x', left - random), 6, 'left', '0'),
#          str_pad(sprintf('%x', random), 2, 'left', '0'),
#          str_pad(sprintf('%x', right - random), 4, 'left', '0'))
#   }
#   
#   phone_to_id(c('13661531790', '13567890000', '13000000001', '13400001000'))



## insert into MST_MODEL

tbl(con_ora_prod, 'MST_MODEL') %>% filter(ID > '10') %>% View

data_frame(ID = '14', MODELNAME = 'cc_bt', VERSION = '1.0', DESCRIPTION = 'cc_bt_model_mars_1.0',
           DELETEFLG = 0, SCORETIME = '2017-07-20', BASELINETIME = '2017-05-31') %>%
  dbWriteTable(con_ora_prod, 'MST_MODEL', ., append = T, row.names = F)

## insert into PHONE_SCORE

# list.files('~/data/models/honeypot_model/old_version/') %>% 
#   purrr::map_df(function(f) {readRDS(paste0('~/data/models/honeypot_model/old_version/', f))
#     }) %>%
#   mutate(PHONE = stringr::str_trim(PHONE)) %>% 
#   filter(substr(PHONE, 1, 3) %in% valid_phone) %>%
#   mutate(SCORE = round(score * 100, 2), MODELID = '13', DELETEFLG = 0L,
#          PARTITION = substr(PHONE, 10, 11),
#          ID = paste0(PHONE, MODELID) ) %>%
#   select(PHONE, SCORE, MODELID, PARTITION, ID, DELETEFLG) %>%
#   dbWriteTable(con, 'PHONE_SCORE', ., append = T, row.names = F)

full_score %>%
  mutate(score = round(score * 100, 2), MODELID = '12', DELETEFLG = 0L,
         PARTITION = substr(phone, 10, 11),
         ID = paste0(phone, MODELID)) %>%
  select(PHONE = phone, SCORE = score, MODELID, PARTITION, ID, DELETEFLG) %>%
  #dbWriteTable(con, 'PHONE_SCORE', ., overwrite = T, row.names = F)
  dbWriteTable(con, 'PHONE_SCORE', ., append = T, row.names = F)


## populate carrier filed in PHONE_POOL table based on phone_carrier_city table in postgresql
add_carrier_to_phone_pool = function(change_flag = F) {
  
  tbl(con_ora_prod, 'PHONE_POOL') %>% group_by(CARRIER) %>% tally %>% print
  if(!change_flag) return()
  
  
  con_pg_util = DBI::dbConnect(dbDriver("PostgreSQL"), 
                               host = '192.168.25.15', 
                               user = 'postgres',
                               password = 'root2017!',
                               dbname = 'score_extraction')
  
  tbl(con_pg_util, 'phone_carrier_city') %>% select(phone_segment, operator) %>% collect -> ref
  
  ## non 170 number, first 3 digit is sufficient to determine carrier
  ref %>% 
    filter(substr(phone_segment, 1, 3) != '170') %>%
    group_by(substr(phone_segment, 1, 3)) %>% 
    summarise(n=n_distinct(operator)) %>% 
    arrange(-n) %>%
    collect %>% 
    pull(n) %>% .[1] -> n.max
  
  if(n.max != 1) stop('first 3 digits not unique for non-170 numbers')
  
  ref %>% filter(operator == '中国电信') %>% mutate(first3 = substr(phone_segment, 1, 3)) %>%
    filter(first3 != '170') %>% select(first3) %>% distinct %>% pull %>% paste0(collapse=',') -> c3
  
  ref %>% filter(operator == '中国移动') %>% mutate(first3 = substr(phone_segment, 1, 3)) %>%
    filter(first3 != '170') %>% select(first3) %>% distinct %>% pull %>% paste0(collapse=',') -> c1
  
  ref %>% filter(operator == '中国联通') %>% mutate(first3 = substr(phone_segment, 1, 3)) %>%
    filter(first3 != '170') %>% select(first3) %>% distinct %>% pull %>% paste0(collapse=',') -> c2
  
  dbExecute(con_ora_prod, paste0("update PHONE_POOL set CARRIER = '3' where CARRIER = '0' and substr(PHONE, 1, 3) IN (", c3, ")"))
  
  dbExecute(con_ora_prod, paste0("update PHONE_POOL set CARRIER = '2' where CARRIER = '0' and substr(PHONE, 1, 3) IN (", c2, ")"))
  
  dbExecute(con_ora_prod, paste0("update PHONE_POOL set CARRIER = '1' where CARRIER = '0' and substr(PHONE, 1, 3) IN (", c1, ")"))
  
  
  ## 170 needs sepcial treatment - first 5 digits
  ref %>% filter(substr(phone_segment, 1, 3) == '170', operator %in% c('中国电信','中国移动', '中国联通')) %>% 
    group_by(substr(phone_segment, 1, 5)) %>%
    summarise(n=n_distinct(operator)) %>% 
    arrange(-n) %>%
    collect %>% 
    pull(n) %>% .[1] -> n.max
  
  if(n.max != 1) stop('first 5 digits not unique for 170 numbers')
  
  ref %>% filter(operator == '中国电信', substr(phone_segment, 1, 3) == '170') %>%
    mutate(first5 = substr(phone_segment, 1, 5)) %>% select(first5) %>% distinct %>% pull %>% paste0(collapse=',') -> c3
  
  ref %>% filter(operator == '中国移动', substr(phone_segment, 1, 3) == '170') %>%
    mutate(first5 = substr(phone_segment, 1, 5)) %>% select(first5) %>% distinct %>% pull %>% paste0(collapse=',') -> c1
  
  ref %>% filter(operator == '中国联通', substr(phone_segment, 1, 3) == '170') %>%
    mutate(first5 = substr(phone_segment, 1, 5)) %>% select(first5) %>% distinct %>% pull %>% paste0(collapse=',') -> c2
  
  dbExecute(con_ora_prod, paste0("update PHONE_POOL set CARRIER = '3' where CARRIER = '0' and substr(PHONE, 1, 5) IN (", c3, ")"))
  
  dbExecute(con_ora_prod, paste0("update PHONE_POOL set CARRIER = '2' where CARRIER = '0' and substr(PHONE, 1, 5) IN (", c2, ")"))
  
  dbExecute(con_ora_prod, paste0("update PHONE_POOL set CARRIER = '1' where CARRIER = '0' and substr(PHONE, 1, 5) IN (", c1, ")"))
  
  tbl(con_ora_prod, 'PHONE_POOL') %>% group_by(CARRIER) %>% tally %>% print
  
}

add_carrier_to_phone_pool()


## insert into DATA_SMS

insert_data_sms = function(data, taskid, modelid) {
  
  tbl(con_ora_prod, 'DATA_SMS') %>% filter(DELETEFLG == 0) %>% summarise(n()) %>% print
  tbl(con_ora_prod, 'DATA_SMS') %>% filter(TASKID == taskid, DELETEFLG == 0) %>% summarise(n()) %>% print
  
  tbl(con_ora_prod, 'ANALY_SAMPLE_RESULT') %>% filter(TASKID == taskid, DELETEFLG == 0) %>%
    collect -> analy_sample_result
  
  if(nrow(analy_sample_result) != 1) stop('more than 1 row in analy_sample_result')
  
  data %>%
    mutate(TASKID = taskid,
           DELETEFLG = 0,
           MODELID = modelid,
           PATRITION = substr(PHONE, 10, 11),
           ID = sapply(paste0(TASKID, PHONE), digest::digest, algo = 'md5'),
           SAMPLEID = analy_sample_result[['SAMPLEID']],
           COPYID   = analy_sample_result[['COPYID']]   ) %>%
    select(MODELID, PHONE, TASKID, PATRITION, DELETEFLG, ID, SAMPLEID, COPYID) %>%
    dbWriteTable(con_ora_prod, 'DATA_SMS', ., append = T, row.names = F)
  
  dbExecute(con_ora_prod, paste0("update MST_TASK set STATUS = 3 where ID = '", taskid, "'"))
  
  tbl(con_ora_prod, 'DATA_SMS') %>% filter(DELETEFLG == 0) %>% summarise(n()) %>% print
  tbl(con_ora_prod, 'DATA_SMS') %>% filter(TASKID == taskid, DELETEFLG == 0) %>% summarise(n()) %>% print
}


## insert into plan_phone

insert_plan_phone = function(data, insertdate, modelid, client) {
  
  tbl(con_ora_prod, 'PLAN_PHONE') %>% summarise(n(), n_distinct(PHONE)) %>% print
  
  data %>%
    mutate(INSERTDATE = insertdate, MODELID = modelid, CLIENT = client) %>%
    select(PHONE, INSERTDATE, MODELID, CLIENT) %>%
    dbWriteTable(con_ora_prod, 'PLAN_PHONE', ., row.names = F, append = T)
  
  tbl(con_ora_prod, 'PLAN_PHONE') %>% summarise(n(), n_distinct(PHONE)) %>% print
  
}


## get taskid from mst_task by start date and end date (both inclusive)

get_taskid = function(start, end) {
  tbl(con_ora_prod, 'MST_TASK') %>% 
    filter(to_char(DELIVERYTIME, 'yyyy-mm-dd') >= start, ## to_data() convert to 00:00:00
           to_char(DELIVERYTIME, 'yyyy-mm-dd') <= end, ## DATA_SMS may have numbers for future job
           DELETEFLG == 0) %>% 
    select(TASKID = ID, DELIVERYTIME, VENDORID, PLANNEDQUANTITY, STATUS) %>% 
    collect %>% arrange(DELIVERYTIME, VENDORID, STATUS) -> task
 
  tbl(con_ora_prod, 'DATA_SMS') %>% filter(TASKID %in% task[['TASKID']]) %>% 
    group_by(TASKID, MODELID) %>% tally %>%
    collect %>% 
    right_join(task) %>% View
  
  return(task)
}

get_taskid('2017-08-18', '2017-08-18')

## remove phones from plan_phone if they exist in data_sms

remove_from_plan_phone = function() {
  
  print('before removal')
  tbl(con_ora_prod, 'PLAN_PHONE') %>% summarise(n(), n_distinct(PHONE)) %>% print
  
  ## get all taskids on or after earlist insert date in plan_phone
  min_insertdate = tbl(con_ora_prod, 'PLAN_PHONE') %>% summarise(min(INSERTDATE)) %>% collect %>% unlist

  task = get_taskid(min_insertdate, '2999-12-31')
  
  ## to see what numbers in plan_phone have been called
  print('numbers to be removed')
  tbl(con_ora_prod, 'PLAN_PHONE') %>% 
    inner_join(
      tbl(con_ora_prod, 'DATA_SMS') %>% 
        filter(TASKID %in% task[['TASKID']], DELETEFLG == 0) %>% 
        select(PHONE, TASKID)) %>% 
    group_by(TASKID, INSERTDATE, CLIENT) %>%
    summarise(n(), n_distinct(PHONE)) %>%
    collect %>%
    inner_join(task) %>% ungroup %>% select(-TASKID) %>% print
  
  # to see what numbers in plan_phone have been called
  dbExecute(con_ora_prod, paste0("DELETE FROM PLAN_PHONE WHERE PHONE in (select PHONE from DATA_SMS where TASKID in ('",
                                 paste0(task[['TASKID']], collapse = "','"), "'))")
  ) %>% print
  
  print('after removal')
  tbl(con_ora_prod, 'PLAN_PHONE') %>% summarise(n(), n_distinct(PHONE))
}

remove_from_plan_phone()


## pull phone numbers by deduping wrt to data_sms and plan_phone

pull_phone_for_task = function(modelid, taskid, sent_start_date, sent_end_date, plan_start_date, count) {
  
  tbl(con_ora_prod, 'PHONE_SCORE') %>% filter(MODELID == modelid) %>%
    anti_join( ## dedup numbers sent in pre and post 3 days
      tbl(con_ora_prod, 'DATA_SMS') %>% 
        filter(TASKID %in% get_taskid(sent_start_date, sent_end_date)[['TASKID']], DELETEFLG == 0) %>% 
        select(PHONE)
    ) %>%
    anti_join( ## dedup numbers in plan_phone
      tbl(con_ora_prod, 'PLAN_PHONE') %>% 
        filter(INSERTDATE >= plan_start_date) %>% 
        select(PHONE) ) %>% 
    select(PHONE, SCORE) %>%
    arrange(desc(SCORE)) %>%
    head(count) %>%
    collect
}

pull_phone_for_task('15', 'aaa', '2017-08-18', '2017-08-24', '2017-08-16', 100)




